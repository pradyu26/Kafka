package com.glo.app.kafkaMessageDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootKafkaMessageDemoTests {

	@Test
	void contextLoads() {
	}

}
