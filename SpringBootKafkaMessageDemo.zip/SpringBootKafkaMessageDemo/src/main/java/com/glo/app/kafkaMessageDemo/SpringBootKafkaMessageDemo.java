package com.glo.app.kafkaMessageDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootKafkaMessageDemo {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootKafkaMessageDemo.class, args);
	}

}
